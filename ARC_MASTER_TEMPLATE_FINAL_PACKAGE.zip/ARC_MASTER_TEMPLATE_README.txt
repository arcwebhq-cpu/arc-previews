ARC MASTER TEMPLATE — VERSION 4.0

Files:
- ARC_MASTER_TEMPLATE.html: permanent template uploaded to GitHub.
- ARC_TEMPLATE_SCHEMA_V2.json: structured content schema for the OpenAI step.

Architecture:
Netlify form -> OpenAI JSON -> Code injects JSON into this exact template -> validation -> GitHub -> delay -> email.

Required validation before upload:
- Starts with <!DOCTYPE html>
- Ends with </html>
- No unresolved {{PLACEHOLDER}} values
- Required sections exist
- Embedded CSS and JavaScript exist

Visual modes:
- clean
- bold
- luxury
- trusted

The template supports optional logo, hero image/video, about image/video, gallery, proof, contact action, and business-specific colors.
